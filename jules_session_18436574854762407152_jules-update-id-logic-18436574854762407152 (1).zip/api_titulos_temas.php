<?php
header('Content-Type: application/json');

$file = 'titulos_temas.json';

// Ensure file exists
if (!file_exists($file)) {
    file_put_contents($file, json_encode([
        'titulos' => [],
        'temas' => [],
        'nextTituloId' => 1,
        'nextTemaId' => 1
    ]));
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo file_get_contents($file);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON']);
        exit;
    }

    $current = json_decode(file_get_contents($file), true);

    // Merge or Update Logic
    // We expect input to contain 'titulos' or 'temas' arrays/objects with ID -> Name
    if (isset($input['titulos'])) {
        foreach ($input['titulos'] as $id => $name) {
            $current['titulos'][$id] = $name;
        }
    }
    if (isset($input['temas'])) {
        foreach ($input['temas'] as $id => $name) {
            $current['temas'][$id] = $name;
        }
    }
    
    // Also update counters if provided (though UUIDs are better, keeping compatibility)
    if (isset($input['nextTituloId'])) $current['nextTituloId'] = $input['nextTituloId'];
    if (isset($input['nextTemaId'])) $current['nextTemaId'] = $input['nextTemaId'];

    if (file_put_contents($file, json_encode($current, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
        echo json_encode(['status' => 'success', 'data' => $current]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save file']);
    }
    exit;
}
?>