<?php
// migracao.php
$ACCESS_KEY = "migracao123";
if (($_REQUEST["key"] ?? "") !== $ACCESS_KEY) die("Acesso Negado. Use ?key=migracao123");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['action']) || $input['action'] !== 'migrate') {
        echo json_encode(['error' => 'Invalid action']);
        exit;
    }

    $modelosData = $input['data'] ?? [];
    $titulosMap = []; // Name -> ID
    $temasMap = []; // Name -> ID
    $newTitulosTemas = ['titulos' => [], 'temas' => []];

    // --- 1. Process local modelosData (Titles/Themes) ---
    if (is_array($modelosData)) {
        foreach ($modelosData as &$tituloObj) {
            $tName = trim($tituloObj['titulo']);
            if (!isset($titulosMap[$tName])) {
                $uuid = uniqid('t_', true); // Generate unique ID
                $titulosMap[$tName] = $uuid;
                $newTitulosTemas['titulos'][$uuid] = $tName;
            }
            $tituloObj['id'] = $titulosMap[$tName]; // Inject ID

            if (isset($tituloObj['temas']) && is_array($tituloObj['temas'])) {
                foreach ($tituloObj['temas'] as &$temaObj) {
                    $tmName = trim($temaObj['tema']);
                    if (!isset($temasMap[$tmName])) {
                        $uuid = uniqid('tm_', true);
                        $temasMap[$tmName] = $uuid;
                        $newTitulosTemas['temas'][$uuid] = $tmName;
                    }
                    $temaObj['id'] = $temasMap[$tmName]; // Inject ID
                }
            }
        }
        unset($tituloObj); // Break reference
        unset($temaObj);
    }

    // --- 2. Process historico_atendimento.txt ---
    $historicoFile = 'historico_atendimento.txt';
    $updatedHistorico = [];
    
    if (file_exists($historicoFile)) {
        $lines = file($historicoFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!empty($lines)) {
            $headerLine = array_shift($lines);
            $headers = explode("\t", $headerLine);
            $titulosIdx = array_search('Título(s)', $headers); // Check exact header name from file reading later if issues
            // Based on salvar_historico.php: 'titulos' => 'Título(s)', 'temas' => 'Tema(s)'
            // But let's be flexible
            if ($titulosIdx === false) $titulosIdx = array_search('titulos', $headers);
            
            $temasIdx = array_search('Tema(s)', $headers);
            if ($temasIdx === false) $temasIdx = array_search('temas', $headers);

            // Keep header
            $updatedHistorico[] = $headerLine;

            foreach ($lines as $line) {
                $cols = explode("\t", $line);
                
                // Process Titles column
                if ($titulosIdx !== false && isset($cols[$titulosIdx])) {
                    $names = explode(';', $cols[$titulosIdx]);
                    $newIds = [];
                    foreach ($names as $name) {
                        $name = trim($name);
                        if ($name === '') continue;
                        if (!isset($titulosMap[$name])) {
                            $uuid = uniqid('t_', true);
                            $titulosMap[$name] = $uuid;
                            $newTitulosTemas['titulos'][$uuid] = $name;
                        }
                        $newIds[] = $titulosMap[$name];
                    }
                    $cols[$titulosIdx] = implode('; ', $newIds);
                }

                // Process Themes column
                if ($temasIdx !== false && isset($cols[$temasIdx])) {
                    $names = explode(';', $cols[$temasIdx]);
                    $newIds = [];
                    foreach ($names as $name) {
                        $name = trim($name);
                        if ($name === '') continue;
                        if (!isset($temasMap[$name])) {
                            $uuid = uniqid('tm_', true);
                            $temasMap[$name] = $uuid;
                            $newTitulosTemas['temas'][$uuid] = $name;
                        }
                        $newIds[] = $temasMap[$name];
                    }
                    $cols[$temasIdx] = implode('; ', $newIds);
                }
                
                $updatedHistorico[] = implode("\t", $cols);
            }
            
            // Backup and Save
            copy($historicoFile, $historicoFile . '.bak');
            file_put_contents($historicoFile, implode(PHP_EOL, $updatedHistorico));
        }
    }

    // --- 3. Save titulos_temas.json ---
    file_put_contents('titulos_temas.json', json_encode($newTitulosTemas, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    echo json_encode(['status' => 'success', 'data' => $modelosData]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Migração de Dados</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { font-family: sans-serif; padding: 20px; text-align: center; }
        button { padding: 15px 30px; font-size: 18px; cursor: pointer; background: #007bff; color: white; border: none; border-radius: 5px; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1>Migração de Dados para Nova Estrutura</h1>
    <p>Esta ferramenta irá atualizar seus dados locais e o histórico no servidor para usar IDs únicos.</p>
    <p>Certifique-se de ter feito backup se necessário.</p>
    <button onclick="startMigration()">Iniciar Migração</button>

    <script>
        async function startMigration() {
            const modelos = JSON.parse(localStorage.getItem('modelosTextoGeral') || '[]');
            
            Swal.fire({
                title: 'Migrando...',
                text: 'Processando dados...',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });

            try {
                const response = await fetch('migracao.php?key=migracao123', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'migrate', data: modelos })
                });
                
                const result = await response.json();
                
                if (result.status === 'success') {
                    // Update localStorage with new structure (IDs injected)
                    localStorage.setItem('modelosTextoGeral', JSON.stringify(result.data));
                    
                    Swal.fire('Sucesso!', 'Migração concluída com sucesso. Os dados foram atualizados.', 'success');
                } else {
                    throw new Error(result.error || 'Erro desconhecido.');
                }
            } catch (error) {
                console.error(error);
                Swal.fire('Erro', 'Falha na migração: ' + error.message, 'error');
            }
        }
    </script>
</body>
</html>